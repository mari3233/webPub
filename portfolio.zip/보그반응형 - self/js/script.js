$(".burger").click(
    function(){
        $(".pop_nav").toggleClass("on");
        $(this).toggleClass("on");
    }
);